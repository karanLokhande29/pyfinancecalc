# pyfinancecalc

A lightweight, dependency-free finance calculations library for Python.

## Features
- Investment: SIP future value, lump sum future value, CAGR, XIRR (no dependencies).
- Loans: EMI, interest/principal split, amortization schedules.
- Planning: Required SIP or lump sum to hit a goal.
- Core: NPV, IRR, rate conversions.

## Quick Start

```bash
pip install pyfinancecalc
```

```python
from pyfinancecalc import sip_future_value, emi, cagr

print(sip_future_value(1000, 0.12, 24))     # SIP FV
print(emi(500000, 0.09, 240))               # EMI
print(cagr(100000, 150000, 2))              # CAGR
```

## XIRR Example
```python
from pyfinancecalc import xirr
cashflows = [-10000, 3000, 3000, 3000, 6000]
dates = [0, 120, 240, 360, 480]  # days from t0
print(xirr(cashflows, dates))
```

## Testing
```bash
pip install pytest
pytest
```
